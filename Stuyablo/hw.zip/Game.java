import java.util.Random;
import java.util.Scanner;

public class Game{
    public static void main(String[]args){

	Adventurer player,opponent;
	player = new Adventurer();
	opponent = new Adventurer();

	// ASKS WHAT CLASS THEY WISH TO BE
	Scanner choice = new Scanner(System.in);
	System.out.println("Choose the letter that represents your class:\n");
	System.out.println("A : Warrior\nB : Wizard\nC : Rogue\n");
	String theChoice = choice.nextLine();
	while(!theChoice.equals("A") && !theChoice.equals("B") && !theChoice.equals("C")){
	    System.out.println("Please choose again:");
	    theChoice = choice.nextLine();
	}

	// ANALYZES THEIR CHOICE
	Scanner namer = new Scanner(System.in);
	if(theChoice.equals("A")){
	    System.out.println("Please name your Warrior:");
	    String name = namer.nextLine();
	    player = new Warrior(name);
	}else
	if(theChoice.equals("B")){
	    System.out.println("Please name your Wizard:");
	    String name = namer.nextLine();
	    player = new Wizard(name);
	}
	if(theChoice.equals("C")){
	    System.out.println("Please name your Rogue:");
	    String name = namer.nextLine();
	    player = new Rogue(name);
	}

	// ATTACKING
	while(player.getHP()>0 && opponent.getHP()>0){
	    Scanner decision = new Scanner(System.in);
	    System.out.println(opponent.getStats());
	    System.out.println(player.getStats());
	    System.out.println("A : Attack");
	    System.out.println("S : Special Attack");
	    System.out.println("G : Give Up");
	    
	    String theDecision = decision.nextLine();
	    if(theDecision.equals("A")){
		player.attack(opponent);
		opponent.attack(player);
	    }
	    if(theDecision.equals("S")){
		player.specialAttack(opponent);
		opponent.specialAttack(player);
	    }
	    if(theDecision.equals("G")){
		System.out.println("\nYou have surrendered to " + opponent.getName()+".");
		player.setHP(0);
	    }
	}
	if(player.getHP()<=0){
	    System.out.println("\n**********" + player.getName()+" has lost the battle to " + opponent.getName() + "!**********\n");
	}else{
	    if(opponent.getHP()<=0){
		System.out.println("\n**********" + player.getName()+" is victorious over " + opponent.getName() + "!**********\n");
	    }
	}
    }
}



